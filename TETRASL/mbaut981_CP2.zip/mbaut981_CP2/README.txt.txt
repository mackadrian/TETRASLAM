Author:	Mack Bautista
Course: COMP2659, Fall 2024
Instructor: Paul Pospisil
Checkpoint: #2
Date: 10-25-2024

Stage 2 Raster Graphics:
	
	Missing clear function for plotting text as is needed when the tile counter updates.
	I will make changes to the clear_bitmap_16 as of CP#2 submission it will be sufficient for now.
	As of right now, clearing a tile will clear the grid lines due to overlap of bitmaps.
	
Stage 3 Events/Models:
	
	I've tried implementing the randomizing of tiles but I have removed it due to it being REALLY SLOW with collision resolution.
	I might have to just hard code initializing all tiles for now to test hypothetical game state.
	Missing events/models of CP#2 submission:
	- Clear rows
	- Updating counter for when the active piece merges with the tiles
	- etc.
	
	More testing needs to be done for the following:
	- Tiles (initializing more tiles)
	- Cycling (test for cycling if the next cycled piece does not fit previously)
	- Clear rows (once implemented)
	- etc.

Stage 4 Rendering:

	As of CP#2 submission, I have only started the basic rendering of the model. 
	That includes more testing needs to be done.